<div class="row">
	<div class="col-lg-12 d-flex justify-content-center">
		<h1 class="my-4">Supermercado ASIR</h1>
	</div>
</div>
<div class="row">
	<div class="col-lg-12 d-flex justify-content-center">
		<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  			<ol class="carousel-indicators">
    			<li data-target="#" data-slide-to="0" class="active"></li>
    			<li data-target="#" data-slide-to="1"></li>
    			<li data-target="#" data-slide-to="2"></li>
  			</ol>
  		<div class="carousel-inner">
    		<div class="carousel-item active">
      			<img class="img-fluid d-block" src="https://elceo.com/wp-content/uploads/2020/11/online.jpg" alt="First slide">
    		</div>
    		<div class="carousel-item">
      			<img class="img-fluid d-block" src="https://www.economiadigital.es/uploads/s1/10/54/23/9/supermercado-DIA.jpg?width=1200&enable=upscale" alt="Second slide">
    		</div>
    		<div class="carousel-item">
      			<img class="img-fluid d-block" src="https://www.merca2.es/wp-content/uploads/2020/04/supermercado-1200x720.jpg" alt="Third slide">
    		</div>
  		</div>
  		<a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    		<span class="carousel-control-prev-icon" aria-hidden="true"></span>
    		<span class="sr-only">Previous</span>
  		</a>
  		<a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    		<span class="carousel-control-next-icon" aria-hidden="true"></span>
    		<span class="sr-only">Next</span>
  		</a>
		</div>
	</div>
</div>