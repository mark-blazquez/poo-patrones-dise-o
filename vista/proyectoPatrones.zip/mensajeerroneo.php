<!DOCTYPE html>
<html>
    <head>
        <?php
            include"./templates/head.php";
        ?>
    </head>
    <body>
        <div class=" container alert alert-danger" role="alert">
            <p class="text-center">la accion no se ha realizado debido a un error intentalo de nuevo</p>
            <div class="d-flex justify-content-center">
                <button class="btn btn-primary " type="button">
                    <a class="text-light" href="empleados.php">ir a pagina de inicio</a>  
                </button>
            </div>
        </div>
    </body>
</html>