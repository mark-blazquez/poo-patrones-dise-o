<!DOCTYPE html>
<html>
    <head>
        <?php
            include"./templates/head.php";
        ?>
    </head>
    <body>
        <div class="container alert alert-success" role="alert">
            <p class="text-center">la accion se ha realizado correctamente , pulsa el boton para volver a la pagina de inicio</p>
            <div class="d-flex justify-content-center">
                <button class="btn btn-primary " type="button">
                    <a class="text-light" href="index.php">ir a pagina de inicio</a>  
                </button>
            </div>
        </div>
    </body>
</html>