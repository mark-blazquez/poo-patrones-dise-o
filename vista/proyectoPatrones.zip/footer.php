<footer class="py-5 bg-dark col-lg-12">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<p class="m-0 text-center text-white">Copyright &copy; Supermercado ASIR 2020</p>
				</div>
				<div class="col-lg-6">
					<p class="m-0 text-center text-white">HECHO POR:</p>
					<p class="m-0 text-center text-white">
						Mark Blázquez // 
						Juanma Loza // 
						Ángel Córdoba
					</p>
				</div>
			</div>
		</div>
		<!-- /.container -->
	</footer>