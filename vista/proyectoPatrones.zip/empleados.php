	<?php
    session_start();
?>
<!DOCTYPE html>
<html>
<?php
    include "./templates/head.php";
?>
<body>
    <br>
    <?php
        include "./templates/headerempleado.php";
    ?>
    <div class=" container ">
        <h2 class="text-center">Página de gestión de productos</h2><br>
        <!--<h4 class="text-center">buenas empleado <?//php echo $empleado->getNombre() ?> con id <?php //echo $empleado->getId() ?> que desea hacer hoy</h4>-->
        <div class="row">
            <div class="col-lg-12" style="text-align: center;">
                <button type="button" class="btn btn-primary" data-toggle="collapse" href="#datos" role="button" aria-expanded="false">Gestionar productos</button>
                <div class="collapse card-header" id="datos">
                    <div class="row">
                        <div class="col-lg-6">
                            <button class="btn btn-secondary" type="button" data-toggle="collapse" href="#crear" role="button" aria-expanded="false">Crear producto</button></br>
                            <div class="btn collapse col-lg-6" data-toggle="collapse" id="crear" href="#crear producto" role="button" aria-expanded="false">
                                <form id="crear producto" action="crearproducto.php" method="post">
                                    <div class="form-group">
                                        <label>Imagen producto</label>
                                        <input type="text" class="form-control" name="urlimagen" placeholder="codigo url de imagen"required>
                                        <label>Nombre producto</label>
                                        <input type="text" class="form-control" name="nombre"  placeholder="nombre"required>
                                        <label>Precio producto</label>
                                        <input type="text" class="form-control" name="precio" placeholder="precio"required>
                                        <label>Tipo producto</label>
                                        <input type="text" class="form-control" name="tipo" placeholder="tipo"required><br>
                                        <input type="submit" value="Introducir">
                                    </div>  
                                </form>
                            </div><br>  
                        </div>                      
                        <div class="col-lg-6">
                            <button class="btn btn-secondary" type="button" class="btn" data-toggle="collapse" href="#borrar" role="button" aria-expanded="false">Borrar productos</button></br>
                            <div class="btn collapse col-lg-6" data-toggle="collapse" id="borrar" href="#borrar producto" role="button" aria-expanded="false">
                                <form id="borrar producto" action="borrarproducto.php" method="post">
                                    <div class="form-group">
                                        <label >Nombre del producto a borrar</label>
                                        <input type="text" class="form-control" name="nombre" placeholder="nombre producto"required><br>
                                        <input type="submit"  value="Introducir">
                                    </div>                                      
                                </form>
                            </div>
                        </div>
                    </div>
                </div>                      
            </div>
        </div>
    </div><br><br>
    <?php
        include "templates/footer.php"
    ?>
</body>
</html>